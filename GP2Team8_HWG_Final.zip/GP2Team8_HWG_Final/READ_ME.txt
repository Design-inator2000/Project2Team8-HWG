build - v1.0 of Obsidian Dream
documents - Contains the ASG, GDD, Concept Document, Team Contract, and a Public Link to the ClickUp Production Plan

How to Play
WASD to move
Avoid getting spotted and reach the Almagem!

Itch link: https://design-inator2000.itch.io/obsidian-dream
Github: https://github.com/Design-inator2000/Project2Team8-HWG.git